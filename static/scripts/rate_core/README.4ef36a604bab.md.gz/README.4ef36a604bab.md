## Core Calculator for Global Rate Comparison

This is the core calculation for TIP global rate recommendations. Given a Level 1 Zone I REFERENCE RATE, a TARGET ZONE (number 0-6), and TITLE, the calculator will return the equivalent rate in the TARGET ZONE.

It does this by first moving left across the zones, then down to the appropriate level.
